// The coincell battery range CR2303: 0-3.0 V
// RFM12B can operate when Vcc>2.2V @ 25mA draw
// Therefore we can only TX if Vcc>2.2V

//don't use the interrupt for safety because not sure what the rfm12b is doing
//#define ADC_INTERRUPT

void setupADCBatt()
{
	  ADC10CTL1 = INCH_11;                      // Channel input is AVcc/2
	  //SREF_1 upper-lower ADC reference to 1.5V which is 3.0/2 V
	  //ADC10SHT_2 sampling time for the ADC is x16 internal ADC clock
	  //REFON turns the reference on
	  //ADC10ON turn the ADC on
#ifdef ADC_INTERRUPT
	  ADC10CTL0 = SREF_1 + ADC10SHT_2 + REFON + ADC10ON  + ADC10IE; // ADC10ON, interrupt enabled

#else
	  ADC10CTL0 = SREF_1 + ADC10SHT_2 + REFON + ADC10ON;
#endif
}

uint8_t checkBatt()
{
ADC10CTL0 |= ENC + ADC10SC;             // Sampling and conversion start
#ifdef ADC_INTERRUPT
	__bis_SR_register(CPUOFF + GIE);        // LPM0, ADC10_ISR will force exit
#else
	while (ADC10CTL1 & ADC10BUSY);          // Poll end of conversion ADC10BUSY
#endif
// If A11 (AVcc/2) < 0311h (0.65V) indicating AVcc is less 2.3V, P1.0 set indicating
//  a lo_Batt condition, else reset.
if (ADC10MEM < 0x311)                   // ADC10MEM = A11 > 0.65?
  return 0; // no we are under 2.3 V
else
  return 1; // yes we have reached 2.3V
}
